import{b as r}from"./_baseUniq-BPZ9VBXa.js";var e=4;function a(o){return r(o,e)}export{a as c};
